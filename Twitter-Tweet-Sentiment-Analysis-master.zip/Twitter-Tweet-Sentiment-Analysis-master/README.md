# Twitter-Tweet-Sentiment-Analysis

open App.py using python3 to run the program on the flask server.

Main.py does all the works and all the functions are placed in different modules that are imported there.
Good luck modifying
